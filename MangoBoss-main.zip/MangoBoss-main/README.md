# MangoBoss
MangoBoss (Mango faucet bot built on vite chain)

## Setup
Get firebase account and download service key. Put it onto project folder and name it "firebase.json"

## Donate <3

    vite: vite_1d81a99f3ed4de1fb0fc05daa8bcfe0e74e939859c9a9b7727
    Eth, bsc, polygon: 0xF2C43249dcE5726BE95Cfa69a525cA06F9dD0cAc
    BTC: bc1qc5ys7lzrzwn45zc73k7fp5fj8lslqksluqd008
    SOL: 2tRU7LTnP4HJxaeUyNbf1UbH7gQaYuBmBmLjR6f9YJs2
    LTC: ltc1qut8gqhrrqw5xryz5rhkqlkuujazkzqgz6w64fz
    XNO/NANO: nano_3qsfbun1w8simrzra6ajygtm7odp3cipcgq3xgs6m9t3qymt5c1qca88qiop
    FLUX: t1eYiT9fDihBQLAPXYi7DngP3s12SPWc5zk
